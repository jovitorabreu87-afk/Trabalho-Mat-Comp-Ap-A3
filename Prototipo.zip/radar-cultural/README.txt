RADAR — PROTÓTIPO FRONT-END

Como abrir:
1. Extraia a pasta radar-cultural.
2. Abra o arquivo index.html no navegador.
   (Também pode usar a extensão Live Server no VS Code.)

O que já funciona:
- Navegação pelas categorias: livros, músicas, séries, filmes, jogos, mangás e HQs.
- Busca por título, autor/artista, categoria, gênero e descrição.
- Favoritar e consultar "Minha lista".
- Botão "Surpreenda-me" para sortear uma recomendação.
- Janela de detalhes para cada indicação.
- Layout responsivo para computador, tablet e celular.

Observações:
- É somente front-end: os dados estão cadastrados no arquivo script.js.
- Os favoritos são salvos localmente no navegador (localStorage), não em um banco de dados.
- O projeto usa HTML, CSS e JavaScript puro, sem framework.
- A folha de estilos importa fontes do Google Fonts; sem internet, o navegador usa fontes alternativas.

Arquivos:
index.html  — estrutura da página
style.css   — identidade visual e responsividade
script.js   — dados de demonstração e interações
