const recommendations = [
  { id: 1, title: 'O Hobbit', creator: 'J. R. R. Tolkien', category: 'Livros', year: '1937', vibe: 'Fantasia', symbol: '⌁', artTitle: 'UMA<br>JORNADA', color: 'linear-gradient(135deg,#b66d43,#5b3541 72%)', description: 'Bilbo Bolseiro leva uma vida tranquila até receber uma visita inesperada. Uma aventura cheia de criaturas fantásticas, mapas misteriosos e descobertas pelo caminho.', mood: 'Para quem quer mergulhar em outro mundo.' },
  { id: 2, title: 'Coraline', creator: 'Neil Gaiman', category: 'Livros', year: '2002', vibe: 'Fantasia sombria', symbol: '◉', artTitle: 'DO OUTRO<br>LADO', color: 'linear-gradient(135deg,#343b72,#171b32 75%)', description: 'Ao explorar sua nova casa, Coraline encontra uma porta para uma versão diferente de sua vida. Uma história imaginativa sobre coragem e escolhas.', mood: 'Para quem gosta de mistério e fantasia.' },
  { id: 3, title: 'Space Song', creator: 'Beach House', category: 'Músicas', year: '2015', vibe: 'Dream pop', symbol: '✧', artTitle: 'FLOAT<br>AWAY', color: 'linear-gradient(135deg,#536f9f,#252d52 78%)', description: 'Uma faixa atmosférica que mistura sintetizadores suaves e vocais etéreos, criando uma sensação de viagem noturna.', mood: 'Para desacelerar e deixar a mente viajar.' },
  { id: 4, title: 'Instant Crush', creator: 'Daft Punk feat. Julian Casablancas', category: 'Músicas', year: '2013', vibe: 'Eletrônica', symbol: '◒', artTitle: 'SYNTH<br>FEELING', color: 'linear-gradient(135deg,#d28b54,#8a3e43 75%)', description: 'Uma combinação marcante de sintetizadores, guitarra e vocais melancólicos em uma produção eletrônica cheia de personalidade.', mood: 'Para entrar no clima sem pressa.' },
  { id: 5, title: 'Arcane', creator: 'Christian Linke e Alex Yee', category: 'Séries', year: '2021', vibe: 'Animação', symbol: '✦', artTitle: 'DOIS<br>MUNDOS', color: 'linear-gradient(135deg,#558c91,#253c54 76%)', description: 'Em meio ao contraste entre duas cidades, histórias pessoais se cruzam com invenções, conflitos e relações complexas. Uma série de animação visualmente marcante.', mood: 'Para quem curte mundos ricos e personagens complexos.' },
  { id: 6, title: 'The Good Place', creator: 'Michael Schur', category: 'Séries', year: '2016', vibe: 'Comédia', symbol: '☼', artTitle: 'O LADO<br>BOA PRAÇA', color: 'linear-gradient(135deg,#7caa81,#3b6d63 80%)', description: 'Uma mulher chega a um lugar que parece perfeito após a vida, mas logo percebe que há algo estranho naquela vizinhança. Comédia leve com questões filosóficas.', mood: 'Para rir e pensar um pouquinho.' },
  { id: 7, title: 'Homem-Aranha: Através do Aranhaverso', creator: 'Joaquim Dos Santos e equipe', category: 'Filmes', year: '2023', vibe: 'Animação', symbol: '◈', artTitle: 'ALÉM DO<br>ARANHAVERSO', color: 'linear-gradient(135deg,#df795f,#7a3c71 80%)', description: 'Miles Morales cruza caminhos com outras versões do herói em uma aventura que expande seu universo e coloca suas escolhas à prova.', mood: 'Para quem procura criatividade visual e aventura.' },
  { id: 8, title: 'A Viagem de Chihiro', creator: 'Hayao Miyazaki', category: 'Filmes', year: '2001', vibe: 'Fantasia', symbol: '☁', artTitle: 'UM MUNDO<br>ENCANTADO', color: 'linear-gradient(135deg,#7ca6a0,#375e6b 80%)', description: 'Durante uma mudança, Chihiro entra em um mundo fantástico habitado por seres extraordinários e precisa encontrar seu próprio caminho.', mood: 'Para uma sessão cheia de imaginação.' },
  { id: 9, title: 'Hollow Knight', creator: 'Team Cherry', category: 'Jogos', year: '2017', vibe: 'Metroidvania', symbol: '♢', artTitle: 'SILÊNCIO<br>EM HOLLOWNEST', color: 'linear-gradient(135deg,#66758f,#252d42 80%)', description: 'Explore um reino subterrâneo interconectado, descubra seus segredos e conheça personagens curiosos em uma aventura de ação e exploração.', mood: 'Para quem gosta de explorar cada cantinho.' },
  { id: 10, title: 'Stardew Valley', creator: 'ConcernedApe', category: 'Jogos', year: '2016', vibe: 'Simulação', symbol: '❀', artTitle: 'VIDA NO<br>CAMPO', color: 'linear-gradient(135deg,#a5ae65,#52735b 80%)', description: 'Comece uma nova vida no campo, cuide da sua fazenda, conheça os moradores e descubra tudo o que o vale tem a oferecer.', mood: 'Para relaxar no seu próprio ritmo.' },
  { id: 11, title: 'Frieren e a Jornada para o Além', creator: 'Kanehito Yamada e Tsukasa Abe', category: 'Mangás', year: '2020', vibe: 'Fantasia', symbol: '✧', artTitle: 'DEPOIS<br>DA JORNADA', color: 'linear-gradient(135deg,#8da18a,#455d68 80%)', description: 'Após o fim de uma grande aventura, uma maga élfica começa uma nova jornada para compreender melhor o tempo, as memórias e as pessoas que conheceu.', mood: 'Para quem aprecia histórias contemplativas.' },
  { id: 12, title: 'Fullmetal Alchemist', creator: 'Hiromu Arakawa', category: 'Mangás', year: '2001', vibe: 'Aventura', symbol: '⚒', artTitle: 'A LEI DA<br>TROCA', color: 'linear-gradient(135deg,#b77a4f,#533e3a 80%)', description: 'Dois irmãos seguem uma jornada em busca de respostas após uma tentativa de alquimia mudar suas vidas. A série combina aventura, humor e dilemas morais.', mood: 'Para quem quer uma história envolvente do começo ao fim.' },
  { id: 13, title: 'Ms. Marvel: Fora do Normal', creator: 'G. Willow Wilson e Adrian Alphona', category: 'HQs', year: '2014', vibe: 'Super-heróis', symbol: '✳', artTitle: 'FORA DO<br>NORMAL', color: 'linear-gradient(135deg,#e58c74,#963d67 80%)', description: 'Kamala Khan é uma adolescente fã de super-heróis que descobre habilidades extraordinárias e precisa descobrir o que significa ser uma heroína.', mood: 'Para conhecer uma heroína cheia de personalidade.' },
  { id: 14, title: 'Batman: Ano Um', creator: 'Frank Miller e David Mazzucchelli', category: 'HQs', year: '1987', vibe: 'Super-heróis', symbol: '◐', artTitle: 'O COMEÇO<br>DO MITO', color: 'linear-gradient(135deg,#69717a,#303b4c 80%)', description: 'Uma releitura dos primeiros passos de Bruce Wayne como Batman e do início da carreira de Jim Gordon em Gotham City.', mood: 'Para quem quer uma história clássica de investigação.' },
  { id: 15, title: 'Fahrenheit 451', creator: 'Ray Bradbury', category: 'Livros', year: '1953', vibe: 'Ficção científica', symbol: '⌂', artTitle: 'IDEIAS<br>EM CHAMAS', color: 'linear-gradient(135deg,#d17a4d,#773f38 80%)', description: 'Em uma sociedade que rejeita livros, um bombeiro começa a questionar o mundo ao seu redor. Uma obra clássica sobre pensamento crítico e conhecimento.', mood: 'Para quem gosta de ficção científica com reflexão.' },
  { id: 16, title: 'Do I Wanna Know?', creator: 'Arctic Monkeys', category: 'Músicas', year: '2013', vibe: 'Indie rock', symbol: '〰', artTitle: 'RIFF<br>MARCANTE', color: 'linear-gradient(135deg,#7c7771,#34353a 80%)', description: 'Um riff de guitarra reconhecível conduz essa faixa de rock alternativo, construída com uma atmosfera lenta e intensa.', mood: 'Para uma playlist de fim de noite.' },
  { id: 17, title: 'Stranger Things', creator: 'The Duffer Brothers', category: 'Séries', year: '2016', vibe: 'Mistério', symbol: '☷', artTitle: 'SINAIS<br>ESTRANHOS', color: 'linear-gradient(135deg,#9b4b4c,#34243c 80%)', description: 'Um grupo de amigos se envolve em acontecimentos inexplicáveis em uma pequena cidade, onde experimentos secretos e mistérios começam a aparecer.', mood: 'Para quem gosta de suspense e amizade.' },
  { id: 18, title: 'Knives Out', creator: 'Rian Johnson', category: 'Filmes', year: '2019', vibe: 'Investigação', symbol: '⌕', artTitle: 'QUEM<br>FOI?', color: 'linear-gradient(135deg,#b5a17a,#53645c 80%)', description: 'Após a morte de um escritor famoso, um detetive investiga uma família cheia de segredos. Um mistério divertido para tentar resolver junto com o filme.', mood: 'Para quem gosta de montar teorias.' },
  { id: 19, title: 'Portal 2', creator: 'Valve', category: 'Jogos', year: '2011', vibe: 'Puzzle', symbol: '◎', artTitle: 'PENSE<br>EM PORTAIS', color: 'linear-gradient(135deg,#79a8b1,#364b65 80%)', description: 'Resolva desafios usando uma ferramenta capaz de criar portais e descubra os mistérios de um laboratório cheio de surpresas.', mood: 'Para exercitar a criatividade e a lógica.' },
  { id: 20, title: 'Witch Hat Atelier', creator: 'Kamome Shirahama', category: 'Mangás', year: '2016', vibe: 'Fantasia', symbol: '♧', artTitle: 'MAGIA<br>DESENHADA', color: 'linear-gradient(135deg,#b3a0c5,#605078 80%)', description: 'Uma jovem fascinada por magia descobre que seus segredos estão ligados a desenhos e símbolos. Uma obra com arte detalhada e um mundo encantador.', mood: 'Para quem gosta de magia e ilustrações caprichadas.' },
  { id: 21, title: 'Scott Pilgrim', creator: 'Bryan Lee O’Malley', category: 'HQs', year: '2004', vibe: 'Comédia', symbol: '♡', artTitle: 'LEVEL<br>UP!', color: 'linear-gradient(135deg,#71a5a1,#40536d 80%)', description: 'Scott Pilgrim tenta equilibrar música, amizades e relacionamentos em uma história que mistura quadrinhos, videogames e cultura pop.', mood: 'Para quem curte humor e referências geek.' },
  { id: 22, title: 'Feel Good Inc.', creator: 'Gorillaz', category: 'Músicas', year: '2005', vibe: 'Alternativo', symbol: '◉', artTitle: 'FEEL<br>THE BEAT', color: 'linear-gradient(135deg,#a4a45e,#465d55 80%)', description: 'Uma mistura de hip-hop alternativo, baixo marcante e melodia cativante que cria uma identidade sonora muito própria.', mood: 'Para dar energia à sua playlist.' },
  { id: 23, title: 'O Castelo Animado', creator: 'Hayao Miyazaki', category: 'Filmes', year: '2004', vibe: 'Fantasia', symbol: '⌂', artTitle: 'UM CASTELO<br>EM MOVIMENTO', color: 'linear-gradient(135deg,#6f9b92,#4a576e 80%)', description: 'Uma jovem recebe uma maldição e acaba encontrando abrigo em um castelo mágico que caminha pelo mundo. Uma aventura sobre identidade e afeto.', mood: 'Para um momento acolhedor e fantástico.' },
  { id: 24, title: 'Celeste', creator: 'Maddy Makes Games', category: 'Jogos', year: '2018', vibe: 'Plataforma', symbol: '▲', artTitle: 'SUBA<br>SEU CAMINHO', color: 'linear-gradient(135deg,#9b86bb,#53678e 80%)', description: 'Ajude Madeline a escalar uma montanha cheia de desafios em um jogo de plataforma preciso, com trilha sonora marcante e narrativa sensível.', mood: 'Para quem gosta de desafios e boas histórias.' }
];

const grid = document.getElementById('recommendationGrid');
const searchInput = document.getElementById('searchInput');
const resultsLabel = document.getElementById('resultsLabel');
const emptyState = document.getElementById('emptyState');
const favoriteCount = document.getElementById('favoriteCount');
const showFavoritesButton = document.getElementById('showFavorites');
const dialog = document.getElementById('detailsDialog');
const dialogContent = document.getElementById('dialogContent');

let activeCategory = 'Todos';
let favoritesOnly = false;
let favorites = loadFavorites();

function loadFavorites() {
  try {
    const saved = JSON.parse(localStorage.getItem('radar-favorites') || '[]');
    return new Set(Array.isArray(saved) ? saved : []);
  } catch (error) {
    return new Set();
  }
}

function saveFavorites() {
  try {
    localStorage.setItem('radar-favorites', JSON.stringify([...favorites]));
  } catch (error) {
    // O protótipo continua funcionando mesmo se o navegador bloquear o armazenamento local.
  }
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[character]);
}

function getFilteredRecommendations() {
  const term = searchInput.value.trim().toLocaleLowerCase('pt-BR');
  return recommendations.filter((item) => {
    const matchesCategory = activeCategory === 'Todos' || item.category === activeCategory;
    const matchesFavorite = !favoritesOnly || favorites.has(item.id);
    const searchable = `${item.title} ${item.creator} ${item.category} ${item.vibe} ${item.description}`.toLocaleLowerCase('pt-BR');
    return matchesCategory && matchesFavorite && (!term || searchable.includes(term));
  });
}

function renderCards() {
  const items = getFilteredRecommendations();
  grid.innerHTML = items.map((item, index) => {
    const isFavorite = favorites.has(item.id);
    return `
      <article class="recommendation-card">
        <div class="card-art" style="--art-bg:${item.color}">
          <div class="art-topline"><span>${escapeHTML(item.category)}</span><span class="art-index">R/${String(index + 1).padStart(2, '0')}</span></div>
          <div class="art-word">${item.artTitle}</div>
          <span class="art-symbol" aria-hidden="true">${item.symbol}</span>
          <button class="favorite-button ${isFavorite ? 'is-favorite' : ''}" type="button" data-favorite="${item.id}" aria-label="${isFavorite ? 'Remover dos' : 'Adicionar aos'} favoritos" aria-pressed="${isFavorite}">${isFavorite ? '♥' : '♡'}</button>
        </div>
        <div class="card-body">
          <div class="card-category"><span>${escapeHTML(item.category)}</span><span class="vibe">${escapeHTML(item.vibe)}</span></div>
          <h3 class="card-title" title="${escapeHTML(item.title)}">${escapeHTML(item.title)}</h3>
          <p class="card-creator">${escapeHTML(item.creator)}</p>
          <div class="card-bottom"><span class="card-year">${escapeHTML(item.year)}</span><button class="details-button" type="button" data-details="${item.id}">Ver detalhes ↗</button></div>
        </div>
      </article>`;
  }).join('');

  const context = favoritesOnly ? 'na sua lista' : activeCategory === 'Todos' ? 'para começar' : `em ${activeCategory.toLocaleLowerCase('pt-BR')}`;
  resultsLabel.textContent = `${items.length} ${items.length === 1 ? 'recomendação' : 'recomendações'} ${context}`;
  emptyState.hidden = items.length !== 0;
  grid.hidden = items.length === 0;
  favoriteCount.textContent = favorites.size;
  showFavoritesButton.classList.toggle('active', favoritesOnly);
  showFavoritesButton.setAttribute('aria-pressed', String(favoritesOnly));
}

function setCategory(category) {
  activeCategory = category;
  document.querySelectorAll('.category-chip').forEach((button) => {
    const selected = button.dataset.category === category;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  renderCards();
}

function toggleFavorite(id) {
  if (favorites.has(id)) favorites.delete(id);
  else favorites.add(id);
  saveFavorites();
  renderCards();
}

function openDetails(id) {
  const item = recommendations.find((recommendation) => recommendation.id === id);
  if (!item) return;
  dialogContent.innerHTML = `
    <div class="dialog-art" style="--art-bg:${item.color}">
      <h2 id="dialogTitle">${escapeHTML(item.title)}</h2>
    </div>
    <div class="dialog-info">
      <div class="dialog-meta">${escapeHTML(item.category)} · ${escapeHTML(item.vibe)} · ${escapeHTML(item.year)}</div>
      <p class="dialog-creator">${escapeHTML(item.creator)}</p>
      <p class="dialog-description">${escapeHTML(item.description)}</p>
      <div class="dialog-vibe">✳ ${escapeHTML(item.mood)}</div>
    </div>`;
  dialog.showModal();
}

function surpriseMe() {
  const pool = getFilteredRecommendations();
  const options = pool.length ? pool : recommendations;
  const chosen = options[Math.floor(Math.random() * options.length)];
  openDetails(chosen.id);
}

document.querySelectorAll('.category-chip').forEach((button) => {
  button.addEventListener('click', () => {
    favoritesOnly = false;
    setCategory(button.dataset.category);
  });
});

grid.addEventListener('click', (event) => {
  const favoriteButton = event.target.closest('[data-favorite]');
  const detailsButton = event.target.closest('[data-details]');
  if (favoriteButton) toggleFavorite(Number(favoriteButton.dataset.favorite));
  if (detailsButton) openDetails(Number(detailsButton.dataset.details));
});

searchInput.addEventListener('input', renderCards);
document.getElementById('searchForm').addEventListener('submit', (event) => {
  event.preventDefault();
  renderCards();
  document.getElementById('explorar').scrollIntoView({ behavior: 'smooth' });
});

showFavoritesButton.addEventListener('click', () => {
  favoritesOnly = !favoritesOnly;
  if (favoritesOnly) setCategory('Todos');
  else renderCards();
  document.getElementById('explorar').scrollIntoView({ behavior: 'smooth' });
});

document.getElementById('surpriseButton').addEventListener('click', surpriseMe);
document.getElementById('bottomSurprise').addEventListener('click', surpriseMe);
document.getElementById('clearFilters').addEventListener('click', () => {
  searchInput.value = '';
  favoritesOnly = false;
  setCategory('Todos');
});
document.getElementById('resetSearch').addEventListener('click', () => {
  searchInput.value = '';
  favoritesOnly = false;
  setCategory('Todos');
});
document.getElementById('closeDialog').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});

renderCards();
